import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Product } from '../product.model';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  @Input() productList : Product[]; //the Product[] passed to us

  //outputs the current Product whenever a new Product is selected
  @Output() onProductSelected : EventEmitter<Product>;
  constructor() {
  this.onProductSelected = new EventEmitter();
}

  //local state containing the currently selected `Product`
  private currentProduct: Product;

  clicked(product: Product): void {
    this.currentProduct = product;
    this.onProductSelected.emit(product);
  }

  isSelected(product: Product): boolean {
    if (!product || !this.currentProduct) {
      return false;
    }
     return product.sku === this.currentProduct.sku;
  }

  ngOnInit() {}

}
